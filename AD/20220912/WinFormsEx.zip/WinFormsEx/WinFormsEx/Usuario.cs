﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsEx
{
    internal class Usuario
    {

        public String nombre { get; set; }
        public int edad { get; set; }
    }
}
